const fs = require('fs');
const path = require('path');
const { fork } = require('child_process');

const serverPath = path.join(__dirname, 'lib', 'system', 'server.js');
let serverProcess = null;

if (!fs.existsSync(serverPath)) {
    console.error(`[Watcher] CRITICAL ERROR: Server file not found at ${serverPath}`);
    process.exit(1);
}

function startServer() {
  if (serverProcess) {
    serverProcess.kill();
    serverProcess = null;
  }

  console.log(`[Watcher] Starting server at ${serverPath}...`);
  serverProcess = fork(serverPath);

  serverProcess.on('exit', (code) => {
    if (code !== 0 && code !== null) {
      console.error(`[Watcher] Server crashed with code ${code}. Restarting in 3 seconds...`);
      setTimeout(startServer, 3000);
    }
  });
}

startServer();

let debounceTimer = null;

function onFileChange(eventType, filename) {
  if (!filename) return;
  if (filename.startsWith('.') || 
      filename.includes('sessions') || 
      filename.includes('db') ||
      filename.includes('node_modules')) {
    return;
  }

  if (debounceTimer) clearTimeout(debounceTimer);
  
  debounceTimer = setTimeout(() => {
    console.log(`[Watcher] File changed: ${filename}. Restarting server...`);
    startServer();
  }, 1000); 
}

fs.watch(__dirname, { recursive: true }, onFileChange);

console.log('[Watcher] Watching for file changes...');
