const { loadRuntime } = require('./lib/app');
loadRuntime();